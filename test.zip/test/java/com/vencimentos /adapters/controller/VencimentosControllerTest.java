package com.vencimentos.adapters.controller;

import com.vencimentos.adapters.application.dto.ContratoResponse;
import com.vencimentos.application.service.ContratoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class VencimentosControllerTest {

    @Mock
    private ContratoService contratoService;

    @InjectMocks
    private VencimentosController vencimentosController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Deve retornar BadRequest quando o parâmetro idEq3Contratante estiver ausente na URL")
    void getContratoSemId_ShouldReturnBadRequest() {
        // Act
        ResponseEntity<?> response = vencimentosController.getContratoSemId();

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("O parâmetro 'idEq3Contratante' é obrigatório na URL.", response.getBody());
    }

    @Test
    @DisplayName("Deve retornar BadRequest quando idEq3Contratante for nulo")
    void getContrato_ShouldReturnBadRequest_WhenIdIsNull() {
        // Act
        ResponseEntity<?> response = vencimentosController.getContrato(null);

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("O parâmetro 'idEq3Contratante' não pode ser vazio.", response.getBody());
        verifyNoInteractions(contratoService); // Garante que o serviço não foi chamado
    }

    @Test
    @DisplayName("Deve retornar BadRequest quando idEq3Contratante for vazio")
    void getContrato_ShouldReturnBadRequest_WhenIdIsBlank() {
        // Act
        ResponseEntity<?> response = vencimentosController.getContrato("   "); // Espaços em branco

        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("O parâmetro 'idEq3Contratante' não pode ser vazio.", response.getBody());
        verifyNoInteractions(contratoService); // Garante que o serviço não foi chamado
    }

    @Test
    @DisplayName("Deve retornar OK com o ContratoResponse quando o contrato for encontrado")
    void getContrato_ShouldReturnOkWithContratoResponse_WhenContratoFound() {
        // Arrange
        String idContratante = "123";
        ContratoResponse mockContratoResponse = new ContratoResponse();
        mockContratoResponse.setIdEq3Contratante(idContratante);
        mockContratoResponse.setNumeroContrato("3232322");

        when(contratoService.buscarContrato(idContratante)).thenReturn(mockContratoResponse);

        // Act
        ResponseEntity<?> response = vencimentosController.getContrato(idContratante);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(mockContratoResponse, response.getBody());
        verify(contratoService, times(1)).buscarContrato(idContratante); // Garante que o serviço foi chamado uma vez
    }

    @Test
    @DisplayName("Deve retornar NotFound quando nenhum contrato for encontrado")
    void getContrato_ShouldReturnNotFound_WhenNoContratoFound() {
        // Arrange
        String idContratante = "456";
        when(contratoService.buscarContrato(idContratante)).thenReturn(null);

        // Act
        ResponseEntity<?> response = vencimentosController.getContrato(idContratante);

        // Assert
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Contratos não encontrados para o id Contratante: " + idContratante, response.getBody());
        verify(contratoService, times(1)).buscarContrato(idContratante);
    }

    @Test
    @DisplayName("Deve retornar InternalServerError quando ocorrer uma exceção no serviço")
    void getContrato_ShouldReturnInternalServerError_WhenServiceThrowsException() {
        // Arrange
        String idContratante = "789";
        String errorMessage = "Erro de conexão com o banco de dados";
        when(contratoService.buscarContrato(idContratante)).thenThrow(new RuntimeException(errorMessage));

        // Act
        ResponseEntity<?> response = vencimentosController.getContrato(idContratante);

        // Assert
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Erro interno no servidor ao buscar o contrato: " + errorMessage, response.getBody());
        verify(contratoService, times(1)).buscarContrato(idContratante);
    }
}