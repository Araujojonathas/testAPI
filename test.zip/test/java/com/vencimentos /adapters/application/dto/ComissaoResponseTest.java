package com.vencimentos.adapters.application.dto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class ComissaoResponseTest {

    @Test
    @DisplayName("Deve instanciar corretamente com os construtores vazio e completo")
    void testConstrutores() {
        // Testa o construtor vazio (sem argumentos)
        ComissaoResponse comissaoResponseNoArgs = new ComissaoResponse();
        assertNotNull(comissaoResponseNoArgs);

        // Testa o construtor com todos os argumentos (AllArgsConstructor)
        ComissaoResponse comissaoResponseAllArgs = new ComissaoResponse(
                1, "Tipo A", "Ativa", "N", "2023-01-01", "2023-01-31",
                new BigDecimal("100.00"), new BigDecimal("90.00"), new BigDecimal("10.00"),
                new BigDecimal("80.00"), new BigDecimal("5.00"), new BigDecimal("2.00"),
                new BigDecimal("1.00"), new BigDecimal("3.00")
        );

        // Valida se os valores atribuídos foram corretamente armazenados
        assertEquals(1, comissaoResponseAllArgs.getNumeroComissao());
        assertEquals("Tipo A", comissaoResponseAllArgs.getTipo());
        assertEquals("Ativa", comissaoResponseAllArgs.getSituacao());
        assertEquals("N", comissaoResponseAllArgs.getIndicadorAtraso());
        assertEquals("2023-01-01", comissaoResponseAllArgs.getDataInicioVigencia());
        assertEquals("2023-01-31", comissaoResponseAllArgs.getDataVencimento());
        assertEquals(new BigDecimal("100.00"), comissaoResponseAllArgs.getValorEsperadoAbertura());
        assertEquals(new BigDecimal("90.00"), comissaoResponseAllArgs.getValorAbertura());
        assertEquals(new BigDecimal("10.00"), comissaoResponseAllArgs.getValorSaldoAtualizado());
        assertEquals(new BigDecimal("80.00"), comissaoResponseAllArgs.getValorPago());
        assertEquals(new BigDecimal("5.00"), comissaoResponseAllArgs.getValorPagoJuros());
        assertEquals(new BigDecimal("2.00"), comissaoResponseAllArgs.getValorMulta());
        assertEquals(new BigDecimal("1.00"), comissaoResponseAllArgs.getValorMora());
        assertEquals(new BigDecimal("3.00"), comissaoResponseAllArgs.getValorJuros());
    }

    @Test
    @DisplayName("Deve testar todos os métodos Getters e Setters")
    void testGettersAndSetters() {
        ComissaoResponse comissaoResponse = new ComissaoResponse();

        // Atribui valores com os setters e valida com os getters
        comissaoResponse.setNumeroComissao(2);
        assertEquals(2, comissaoResponse.getNumeroComissao());

        comissaoResponse.setTipo("Tipo B");
        assertEquals("Tipo B", comissaoResponse.getTipo());

        comissaoResponse.setSituacao("Inativa");
        assertEquals("Inativa", comissaoResponse.getSituacao());

        comissaoResponse.setIndicadorAtraso("S");
        assertEquals("S", comissaoResponse.getIndicadorAtraso());

        comissaoResponse.setDataInicioVigencia("2023-02-01");
        assertEquals("2023-02-01", comissaoResponse.getDataInicioVigencia());

        comissaoResponse.setDataVencimento("2023-02-28");
        assertEquals("2023-02-28", comissaoResponse.getDataVencimento());

        comissaoResponse.setValorEsperadoAbertura(new BigDecimal("200.00"));
        assertEquals(new BigDecimal("200.00"), comissaoResponse.getValorEsperadoAbertura());

        comissaoResponse.setValorAbertura(new BigDecimal("180.00"));
        assertEquals(new BigDecimal("180.00"), comissaoResponse.getValorAbertura());

        comissaoResponse.setValorSaldoAtualizado(new BigDecimal("20.00"));
        assertEquals(new BigDecimal("20.00"), comissaoResponse.getValorSaldoAtualizado());

        comissaoResponse.setValorPago(new BigDecimal("150.00"));
        assertEquals(new BigDecimal("150.00"), comissaoResponse.getValorPago());

        comissaoResponse.setValorPagoJuros(new BigDecimal("10.00"));
        assertEquals(new BigDecimal("10.00"), comissaoResponse.getValorPagoJuros());

        comissaoResponse.setValorMulta(new BigDecimal("4.00"));
        assertEquals(new BigDecimal("4.00"), comissaoResponse.getValorMulta());

        comissaoResponse.setValorMora(new BigDecimal("2.00"));
        assertEquals(new BigDecimal("2.00"), comissaoResponse.getValorMora());

        comissaoResponse.setValorJuros(new BigDecimal("6.00"));
        assertEquals(new BigDecimal("6.00"), comissaoResponse.getValorJuros());
    }

    @Test
    @DisplayName("Deve construir objeto utilizando o padrão Builder")
    void testBuilder() {
        // Criação utilizando o builder
        ComissaoResponse comissaoResponse = ComissaoResponse.builder()
                .numeroComissao(3)
                .tipo("Tipo C")
                .situacao("Pendente")
                .indicadorAtraso("N")
                .dataInicioVigencia("2023-03-01")
                .dataVencimento("2023-03-31")
                .valorEsperadoAbertura(new BigDecimal("300.00"))
                .valorAbertura(new BigDecimal("280.00"))
                .valorSaldoAtualizado(new BigDecimal("20.00"))
                .valorPago(new BigDecimal("250.00"))
                .valorPagoJuros(new BigDecimal("15.00"))
                .valorMulta(new BigDecimal("6.00"))
                .valorMora(new BigDecimal("3.00"))
                .valorJuros(new BigDecimal("9.00"))
                .build();

        // Valida se os campos foram corretamente preenchidos
        assertNotNull(comissaoResponse);
        assertEquals(3, comissaoResponse.getNumeroComissao());
        assertEquals("Tipo C", comissaoResponse.getTipo());
        assertEquals("Pendente", comissaoResponse.getSituacao());
        assertEquals("N", comissaoResponse.getIndicadorAtraso());
        assertEquals("2023-03-01", comissaoResponse.getDataInicioVigencia());
        assertEquals("2023-03-31", comissaoResponse.getDataVencimento());
        assertEquals(new BigDecimal("300.00"), comissaoResponse.getValorEsperadoAbertura());
        assertEquals(new BigDecimal("280.00"), comissaoResponse.getValorAbertura());
        assertEquals(new BigDecimal("20.00"), comissaoResponse.getValorSaldoAtualizado());
        assertEquals(new BigDecimal("250.00"), comissaoResponse.getValorPago());
        assertEquals(new BigDecimal("15.00"), comissaoResponse.getValorPagoJuros());
        assertEquals(new BigDecimal("6.00"), comissaoResponse.getValorMulta());
        assertEquals(new BigDecimal("3.00"), comissaoResponse.getValorMora());
        assertEquals(new BigDecimal("9.00"), comissaoResponse.getValorJuros());
    }

    @Test
    @DisplayName("Deve permitir campos BigDecimal nulos (JsonInclude.NON_NULL)")
    void testJsonIncludeNonNull() {
        // Apenas alguns campos são preenchidos. Os demais devem ser nulos.
        ComissaoResponse comissaoResponse = ComissaoResponse.builder()
                .numeroComissao(4)
                .tipo("Tipo D")
                .situacao("Concluída")
                .indicadorAtraso("N")
                .dataInicioVigencia("2023-04-01")
                .dataVencimento("2023-04-30")
                .valorEsperadoAbertura(new BigDecimal("400.00"))
                .valorPago(new BigDecimal("350.00"))
                .build();

        assertNotNull(comissaoResponse);
        assertEquals(new BigDecimal("400.00"), comissaoResponse.getValorEsperadoAbertura());
        assertNull(comissaoResponse.getValorAbertura());
        assertNull(comissaoResponse.getValorSaldoAtualizado());
        assertEquals(new BigDecimal("350.00"), comissaoResponse.getValorPago());
        assertNull(comissaoResponse.getValorPagoJuros());
        assertNull(comissaoResponse.getValorMulta());
        assertNull(comissaoResponse.getValorMora());
        assertNull(comissaoResponse.getValorJuros());
    }

    @Test
    @DisplayName("Deve validar os métodos equals e hashCode gerados pelo Lombok")
    void testEqualsAndHashCode() {
        ComissaoResponse comissao1 = ComissaoResponse.builder()
                .numeroComissao(1)
                .tipo("Tipo Teste")
                .build();

        ComissaoResponse comissao2 = ComissaoResponse.builder()
                .numeroComissao(1)
                .tipo("Tipo Teste")
                .build();

        ComissaoResponse comissao3 = ComissaoResponse.builder()
                .numeroComissao(2)
                .tipo("Tipo Diferente")
                .build();

        // Testa igualdade lógica
        assertEquals(comissao1, comissao2);
        assertNotEquals(comissao1, comissao3);

        // Testa igualdade de hashCode
        assertEquals(comissao1.hashCode(), comissao2.hashCode());
        assertNotEquals(comissao1.hashCode(), comissao3.hashCode());
    }
}
