package com.vencimentos.adapters.application.dto;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ContratoResponseTest {

    @Test
    @DisplayName("Deve instanciar corretamente com construtores vazio e completo")
    void testConstrutores() {
        // Testando o construtor sem argumentos (NoArgsConstructor)
        ContratoResponse contratoResponseNoArgs = new ContratoResponse();
        assertNotNull(contratoResponseNoArgs);

        // Testando o construtor com todos os argumentos (AllArgsConstructor)
        List<ComissaoResponse> comissoes = Arrays.asList(
                new ComissaoResponse(1, "Tipo A", "Ativa", "N", "2023-01-01", "2023-01-31", null, null, null, null, null, null, null, null),
                new ComissaoResponse(2, "Tipo B", "Pendente", "S", "2023-02-01", "2023-02-28", null, null, null, null, null, null, null, null)
        );

        ContratoResponse contratoResponseAllArgs = new ContratoResponse(
                "CONTRATO-001", "EQ3-CONTRATANTE-001", "EQ3-CREDOR-001",
                new BigDecimal("1000.00"), new BigDecimal("950.00"),
                "2023-01-01", "2024-01-01", "IPCA", new BigDecimal("0.05"),
                "MENSAL", 1, comissoes
        );

        // Validações
        assertNotNull(contratoResponseAllArgs);
        assertEquals("CONTRATO-001", contratoResponseAllArgs.getNumeroContrato());
        assertEquals("EQ3-CONTRATANTE-001", contratoResponseAllArgs.getIdEq3Contratante());
        assertEquals("EQ3-CREDOR-001", contratoResponseAllArgs.getIdEq3Credor());
        assertEquals(new BigDecimal("1000.00"), contratoResponseAllArgs.getValorAbertura());
        assertEquals(new BigDecimal("950.00"), contratoResponseAllArgs.getValorSaldoAtualizado());
        assertEquals("2023-01-01", contratoResponseAllArgs.getDataInicioOperacao());
        assertEquals("2024-01-01", contratoResponseAllArgs.getDataLimiteOperacao());
        assertEquals("IPCA", contratoResponseAllArgs.getNomeIndexador());
        assertEquals(new BigDecimal("0.05"), contratoResponseAllArgs.getPercentualTaxaCarta());
        assertEquals("MENSAL", contratoResponseAllArgs.getTipoPagamentoComissao());
        assertEquals(1, contratoResponseAllArgs.getPeriodicidadeComissao());
        assertEquals(2, contratoResponseAllArgs.getComissoes().size());
    }

    @Test
    @DisplayName("Deve testar os métodos Getters e Setters")
    void testGettersAndSetters() {
        ContratoResponse contratoResponse = new ContratoResponse();

        // Setando valores usando setters e validando com getters
        contratoResponse.setNumeroContrato("CONTRATO-002");
        assertEquals("CONTRATO-002", contratoResponse.getNumeroContrato());

        contratoResponse.setIdEq3Contratante("EQ3-CONTRATANTE-002");
        assertEquals("EQ3-CONTRATANTE-002", contratoResponse.getIdEq3Contratante());

        contratoResponse.setIdEq3Credor("EQ3-CREDOR-002");
        assertEquals("EQ3-CREDOR-002", contratoResponse.getIdEq3Credor());

        contratoResponse.setValorAbertura(new BigDecimal("2000.00"));
        assertEquals(new BigDecimal("2000.00"), contratoResponse.getValorAbertura());

        contratoResponse.setValorSaldoAtualizado(new BigDecimal("1900.00"));
        assertEquals(new BigDecimal("1900.00"), contratoResponse.getValorSaldoAtualizado());

        contratoResponse.setDataInicioOperacao("2023-03-01");
        contratoResponse.setDataLimiteOperacao("2024-03-01");

        contratoResponse.setNomeIndexador("CDI");
        contratoResponse.setPercentualTaxaCarta(new BigDecimal("0.07"));
        contratoResponse.setTipoPagamentoComissao("ANUAL");
        contratoResponse.setPeriodicidadeComissao(12);

        List<ComissaoResponse> comissoes = new ArrayList<>();
        comissoes.add(new ComissaoResponse(3, "Tipo C", "Finalizada", "N", "2023-03-01", "2023-03-31", null, null, null, null, null, null, null, null));
        contratoResponse.setComissoes(comissoes);

        assertEquals(1, contratoResponse.getComissoes().size());
    }

    @Test
    @DisplayName("Deve construir objeto usando o padrão Builder")
    void testBuilder() {
        // Criando comissões com o builder
        ComissaoResponse comissao1 = ComissaoResponse.builder().numeroComissao(10).tipo("Tipo X").build();
        ComissaoResponse comissao2 = ComissaoResponse.builder().numeroComissao(20).tipo("Tipo Y").build();

        // Construindo contrato com builder
        ContratoResponse contratoResponse = ContratoResponse.builder()
                .numeroContrato("CONTRATO-003")
                .idEq3Contratante("EQ3-CONTRATANTE-003")
                .idEq3Credor("EQ3-CREDOR-003")
                .valorAbertura(new BigDecimal("3000.00"))
                .valorSaldoAtualizado(new BigDecimal("2900.00"))
                .dataInicioOperacao("2023-04-01")
                .dataLimiteOperacao("2024-04-01")
                .nomeIndexador("SELIC")
                .percentualTaxaCarta(new BigDecimal("0.03"))
                .tipoPagamentoComissao("SEMESTRAL")
                .periodicidadeComissao(6)
                .comissoes(Arrays.asList(comissao1, comissao2))
                .build();

        assertEquals("CONTRATO-003", contratoResponse.getNumeroContrato());
        assertEquals(2, contratoResponse.getComissoes().size());
    }

    @Test
    @DisplayName("Deve construir contrato com lista de comissões vazia")
    void testBuilderComListaVazia() {
        ContratoResponse contratoResponse = ContratoResponse.builder()
                .numeroContrato("CONTRATO-004")
                .comissoes(Collections.emptyList())
                .build();

        assertNotNull(contratoResponse.getComissoes());
        assertTrue(contratoResponse.getComissoes().isEmpty());
    }

    @Test
    @DisplayName("Deve validar igualdade e hashCode gerados pelo Lombok")
    void testEqualsAndHashCode() {
        List<ComissaoResponse> comissoes1 = Arrays.asList(
                ComissaoResponse.builder().numeroComissao(1).build(),
                ComissaoResponse.builder().numeroComissao(2).build()
        );
        List<ComissaoResponse> comissoes2 = Arrays.asList(
                ComissaoResponse.builder().numeroComissao(1).build(),
                ComissaoResponse.builder().numeroComissao(2).build()
        );
        List<ComissaoResponse> comissoes3 = Arrays.asList(
                ComissaoResponse.builder().numeroComissao(1).build(),
                ComissaoResponse.builder().numeroComissao(3).build()
        );

        ContratoResponse contrato1 = ContratoResponse.builder()
                .numeroContrato("C-TEST-001")
                .valorAbertura(new BigDecimal("100.00"))
                .comissoes(comissoes1)
                .build();

        ContratoResponse contrato2 = ContratoResponse.builder()
                .numeroContrato("C-TEST-001")
                .valorAbertura(new BigDecimal("100.00"))
                .comissoes(comissoes2)
                .build();

        ContratoResponse contrato3 = ContratoResponse.builder()
                .numeroContrato("C-TEST-002")
                .valorAbertura(new BigDecimal("100.00"))
                .comissoes(comissoes1)
                .build();

        ContratoResponse contrato4 = ContratoResponse.builder()
                .numeroContrato("C-TEST-001")
                .valorAbertura(new BigDecimal("200.00"))
                .comissoes(comissoes1)
                .build();

        ContratoResponse contrato5 = ContratoResponse.builder()
                .numeroContrato("C-TEST-001")
                .valorAbertura(new BigDecimal("100.00"))
                .comissoes(comissoes3)
                .build();

        // Comparações
        assertEquals(contrato1, contrato2);
        assertNotEquals(contrato1, contrato3);
        assertNotEquals(contrato1, contrato4);
        assertNotEquals(contrato1, contrato5);

        // Validação dos hashCodes
        assertEquals(contrato1.hashCode(), contrato2.hashCode());
        assertNotEquals(contrato1.hashCode(), contrato3.hashCode());
        assertNotEquals(contrato1.hashCode(), contrato4.hashCode());
        assertNotEquals(contrato1.hashCode(), contrato5.hashCode());
    }
}
