package com.vencimentos.domain.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

// Classe de teste para a classe de modelo Comissao.
// Utiliza JUnit 5 para a execução dos testes de unidade.
class ComissaoTest {

    private Comissao comissao; // Instância da classe Comissao a ser testada em cada método de teste.

    // Método de configuração que é executado antes de cada método de teste.
    // Garante que uma nova instância de Comissao com dados conhecidos
    // esteja disponível para cada teste, promovendo o isolamento.
    @BeforeEach
    void setUp() {
        comissao = new Comissao(
                1, // numeroComissao
                "Venda Direta", // tipo
                "Pendente", // situacao
                "Nao", // indicadorAtraso
                "2023-01-15", // dataInicioVigencia
                "2023-02-15", // dataVencimento
                new BigDecimal("1500.00"), // valorEsperadoAbertura
                new BigDecimal("1450.00"), // valorAbertura
                new BigDecimal("750.00"), // valorSaldoAtualizado
                new BigDecimal("700.00"), // valorPago
                new BigDecimal("15.00"), // valorPagoJuros
                new BigDecimal("30.00"), // valorMulta
                new BigDecimal("10.00"), // valorMora
                new BigDecimal("20.00") // valorJuros
        );
    }

    @Test
    @DisplayName("Deve criar a Comissao com todos os argumentos fornecidos")
    void shouldCreateComissaoWithAllArguments() {
        // Verifica se a instância da Comissao não é nula, indicando que foi criada com sucesso.
        assertNotNull(comissao, "A instância de Comissao não deve ser nula.");
        // Verifica se cada atributo da Comissao corresponde aos valores passados no construtor.
        assertEquals(1, comissao.getNumeroComissao(), "O número da comissão deve ser 1.");
        assertEquals("Venda Direta", comissao.getTipo(), "O tipo da comissão deve ser 'Venda Direta'.");
        assertEquals("Pendente", comissao.getSituacao(), "A situação da comissão deve ser 'Pendente'.");
        assertEquals("Nao", comissao.getIndicadorAtraso(), "O indicador de atraso deve ser 'Nao'.");
        assertEquals("2023-01-15", comissao.getDataInicioVigencia(), "A data de início de vigência deve ser '2023-01-15'.");
        assertEquals("2023-02-15", comissao.getDataVencimento(), "A data de vencimento deve ser '2023-02-15'.");
        assertEquals(new BigDecimal("1500.00"), comissao.getValorEsperadoAbertura(), "O valor esperado de abertura deve ser 1500.00.");
        assertEquals(new BigDecimal("1450.00"), comissao.getValorAbertura(), "O valor de abertura deve ser 1450.00.");
        assertEquals(new BigDecimal("750.00"), comissao.getValorSaldoAtualizado(), "O valor do saldo atualizado deve ser 750.00.");
        assertEquals(new BigDecimal("700.00"), comissao.getValorPago(), "O valor pago deve ser 700.00.");
        assertEquals(new BigDecimal("15.00"), comissao.getValorPagoJuros(), "O valor pago de juros deve ser 15.00.");
        assertEquals(new BigDecimal("30.00"), comissao.getValorMulta(), "O valor da multa deve ser 30.00.");
        assertEquals(new BigDecimal("10.00"), comissao.getValorMora(), "O valor da mora deve ser 10.00.");
        assertEquals(new BigDecimal("20.00"), comissao.getValorJuros(), "O valor dos juros deve ser 20.00.");
    }

    @Test
    @DisplayName("Deve testar os métodos Getters e Setters")
    void shouldTestGettersAndSetters() {
        // Cria uma nova instância de Comissao usando o construtor sem argumentos.
        Comissao newComissao = new Comissao();
        // Define novos valores para cada atributo usando os métodos setters.
        newComissao.setNumeroComissao(2);
        newComissao.setTipo("Serviço Recorrente");
        newComissao.setSituacao("Aprovada");
        newComissao.setIndicadorAtraso("Sim");
        newComissao.setDataInicioVigencia("2024-03-01");
        newComissao.setDataVencimento("2024-04-01");
        newComissao.setValorEsperadoAbertura(new BigDecimal("2500.00"));
        newComissao.setValorAbertura(new BigDecimal("2400.00"));
        newComissao.setValorSaldoAtualizado(new BigDecimal("1200.00"));
        newComissao.setValorPago(new BigDecimal("1200.00"));
        newComissao.setValorPagoJuros(new BigDecimal("25.00"));
        newComissao.setValorMulta(new BigDecimal("50.00"));
        newComissao.setValorMora(new BigDecimal("20.00"));
        newComissao.setValorJuros(new BigDecimal("40.00"));

        // Verifica se os valores recuperados pelos getters correspondem aos valores que foram definidos.
        assertEquals(2, newComissao.getNumeroComissao(), "O número da comissão deve ser 2.");
        assertEquals("Serviço Recorrente", newComissao.getTipo(), "O tipo da comissão deve ser 'Serviço Recorrente'.");
        assertEquals("Aprovada", newComissao.getSituacao(), "A situação da comissão deve ser 'Aprovada'.");
        assertEquals("Sim", newComissao.getIndicadorAtraso(), "O indicador de atraso deve ser 'Sim'.");
        assertEquals("2024-03-01", newComissao.getDataInicioVigencia(), "A data de início de vigência deve ser '2024-03-01'.");
        assertEquals("2024-04-01", newComissao.getDataVencimento(), "A data de vencimento deve ser '2024-04-01'.");
        assertEquals(new BigDecimal("2500.00"), newComissao.getValorEsperadoAbertura(), "O valor esperado de abertura deve ser 2500.00.");
        assertEquals(new BigDecimal("2400.00"), newComissao.getValorAbertura(), "O valor de abertura deve ser 2400.00.");
        assertEquals(new BigDecimal("1200.00"), newComissao.getValorSaldoAtualizado(), "O valor do saldo atualizado deve ser 1200.00.");
        assertEquals(new BigDecimal("1200.00"), newComissao.getValorPago(), "O valor pago deve ser 1200.00.");
        assertEquals(new BigDecimal("25.00"), newComissao.getValorPagoJuros(), "O valor pago de juros deve ser 25.00.");
        assertEquals(new BigDecimal("50.00"), newComissao.getValorMulta(), "O valor da multa deve ser 50.00.");
        assertEquals(new BigDecimal("20.00"), newComissao.getValorMora(), "O valor da mora deve ser 20.00.");
        assertEquals(new BigDecimal("40.00"), newComissao.getValorJuros(), "O valor dos juros deve ser 40.00.");
    }

    @Test
    @DisplayName("Deve testar o construtor sem argumentos (NoArgsConstructor)")
    void shouldTestNoArgsConstructor() {
        // Testa se o construtor sem argumentos (gerado pelo Lombok) funciona corretamente,
        // criando uma instância de Comissao que não é nula.
        Comissao noArgsComissao = new Comissao();
        assertNotNull(noArgsComissao, "A instância de Comissao criada pelo construtor sem argumentos não deve ser nula.");
    }

    @Test
    @DisplayName("Deve testar os métodos equals e hashCode")
    void shouldTestEqualsAndHashCodeMethods() {
        // Cria uma nova instância de Comissao com os mesmos valores da instância `comissao` do `setUp`.
        // Esta instância deve ser considerada "igual" pelo método equals.
        Comissao sameComissao = new Comissao(
                1,
                "Venda Direta",
                "Pendente",
                "Nao",
                "2023-01-15",
                "2023-02-15",
                new BigDecimal("1500.00"),
                new BigDecimal("1450.00"),
                new BigDecimal("750.00"),
                new BigDecimal("700.00"),
                new BigDecimal("15.00"),
                new BigDecimal("30.00"),
                new BigDecimal("10.00"),
                new BigDecimal("20.00")
        );

        // Cria uma nova instância de Comissao com valores diferentes.
        // Esta instância não deve ser considerada "igual" pelo método equals.
        Comissao differentComissao = new Comissao(
                99, // Diferente numeroComissao
                "Outro Tipo", // Diferente tipo
                "Concluída",
                "Nao",
                "2023-05-01",
                "2023-06-01",
                new BigDecimal("500.00"),
                new BigDecimal("480.00"),
                new BigDecimal("0.00"),
                new BigDecimal("480.00"),
                new BigDecimal("0.00"),
                new BigDecimal("0.00"),
                new BigDecimal("0.00"),
                new BigDecimal("0.00")
        );

        // Verifica se `comissao` é igual a `sameComissao`.
        assertEquals(comissao, sameComissao, "Objetos com os mesmos atributos devem ser iguais.");
        // Verifica se `comissao` não é igual a `differentComissao`.
        assertNotEquals(comissao, differentComissao, "Objetos com atributos diferentes não devem ser iguais.");
        // Verifica se o hashCode é o mesmo para objetos considerados iguais.
        assertEquals(comissao.hashCode(), sameComissao.hashCode(), "Hash codes devem ser iguais para objetos iguais.");
        // Verifica se o hashCode é diferente para objetos considerados diferentes.
        assertNotEquals(comissao.hashCode(), differentComissao.hashCode(), "Hash codes devem ser diferentes para objetos diferentes.");
    }

    @Test
    @DisplayName("Deve testar o método toString")
    void shouldTestToStringMethod() {
        // Define uma parte esperada da string gerada pelo método toString() do Lombok.
        // O Lombok gera um toString que inclui todos os campos.
        String expectedToStringPart = "Comissao(numeroComissao=1, tipo=Venda Direta, situacao=Pendente";
        // Verifica se a string gerada por toString() contém a parte esperada.
        assertTrue(comissao.toString().contains(expectedToStringPart), "O toString deve conter a parte esperada.");
        // Verifica se o toString também inclui o valor de um campo BigDecimal.
        assertTrue(comissao.toString().contains("valorEsperadoAbertura=1500.00"), "O toString deve incluir 'valorEsperadoAbertura'.");
    }
}