package com.vencimentos.domain.model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

// Classe de teste para a classe Contrato.
// Utiliza JUnit 5 para a execução dos testes.
class ContratoTest {

    private Contrato contrato; // Instância de Contrato a ser testada
    private Comissao comissao1; // Primeira instância de Comissao para a lista de comissões
    private Comissao comissao2; // Segunda instância de Comissao para a lista de comissões

    // Método executado antes de cada teste, para configurar um ambiente limpo.
    @BeforeEach
    void setUp() {
        // Inicializa comissao1 com dados de exemplo
        comissao1 = new Comissao(
                1, "Venda", "Aberta", "Nao",
                "2024-01-01", "2024-02-01",
                new BigDecimal("1000.00"), new BigDecimal("950.00"),
                new BigDecimal("500.00"), new BigDecimal("450.00"),
                new BigDecimal("10.00"), new BigDecimal("20.00"),
                new BigDecimal("5.00"), new BigDecimal("15.00")
        );

        // Inicializa comissao2 com dados de exemplo
        comissao2 = new Comissao(
                2, "Servico", "Paga", "Nao",
                "2024-03-01", "2024-04-01",
                new BigDecimal("2000.00"), new BigDecimal("1900.00"),
                new BigDecimal("0.00"), new BigDecimal("1900.00"),
                new BigDecimal("0.00"), new BigDecimal("0.00"),
                new BigDecimal("0.00"), new BigDecimal("0.00")
        );

        // Cria uma lista de comissões usando as instâncias criadas
        List<Comissao> comissoes = Arrays.asList(comissao1, comissao2);

        // Inicializa o objeto contrato com dados de exemplo e a lista de comissões
        contrato = new Contrato(
                "CONTRATO-001",
                "EQ3-CONTRATANTE-XYZ",
                "EQ3-CREDOR-ABC",
                new BigDecimal("50000.00"),
                new BigDecimal("25000.00"),
                "2023-01-01",
                "2025-12-31",
                "IPCA",
                new BigDecimal("0.5"),
                "Mensal",
                "Boleto",
                30,
                comissoes
        );
    }

    @Test
    @DisplayName("Deve criar Contrato com todos os argumentos")
    void shouldCreateContratoWithAllArguments() {
        // Verifica se o objeto contrato não é nulo após a criação
        assertNotNull(contrato);
        // Verifica se cada atributo do contrato foi inicializado corretamente
        assertEquals("CONTRATO-001", contrato.getNumeroContrato());
        assertEquals("EQ3-CONTRATANTE-XYZ", contrato.getIdEq3Contratante());
        assertEquals("EQ3-CREDOR-ABC", contrato.getIdEq3Credor());
        assertEquals(new BigDecimal("50000.00"), contrato.getValorContratoAbertura());
        assertEquals(new BigDecimal("25000.00"), contrato.getValorSaldoAtualizadoContrato());
        assertEquals("2023-01-01", contrato.getDataInicioOperacao());
        assertEquals("2025-12-31", contrato.getDataLimiteOperacao());
        assertEquals("IPCA", contrato.getNomeIndexador());
        assertEquals(new BigDecimal("0.5"), contrato.getPercentualTaxaCarta());
        assertEquals("Mensal", contrato.getTipoPagamentoComissao());
        assertEquals("Boleto", contrato.getFormaPagamento());
        assertEquals(30, contrato.getPeriodicidadeComissao());
        // Verifica se a lista de comissões não é nula
        assertNotNull(contrato.getComissoes());
        // Verifica se o tamanho da lista de comissões está correto
        assertEquals(2, contrato.getComissoes().size());
        // Verifica se as comissões esperadas estão presentes na lista
        assertTrue(contrato.getComissoes().contains(comissao1));
        assertTrue(contrato.getComissoes().contains(comissao2));
    }

    @Test
    @DisplayName("Deve testar Getters e Setters")
    void shouldTestGettersAndSetters() {
        // Cria uma nova instância de Contrato usando o construtor padrão (sem argumentos)
        Contrato newContrato = new Contrato();
        // Define novos valores para os atributos usando os setters
        newContrato.setNumeroContrato("CONTRATO-002");
        newContrato.setIdEq3Contratante("EQ3-CONTRATANTE-ABC");
        newContrato.setIdEq3Credor("EQ3-CREDOR-XYZ");
        newContrato.setValorContratoAbertura(new BigDecimal("60000.00"));
        newContrato.setValorSaldoAtualizadoContrato(new BigDecimal("30000.00"));
        newContrato.setDataInicioOperacao("2024-06-01");
        newContrato.setDataLimiteOperacao("2026-06-01");
        newContrato.setNomeIndexador("CDI");
        newContrato.setPercentualTaxaCarta(new BigDecimal("0.75"));
        newContrato.setTipoPagamentoComissao("Trimestral");
        newContrato.setFormaPagamento("Cartao");
        newContrato.setPeriodicidadeComissao(90);
        // Define a lista de comissões com apenas uma comissão para este teste
        newContrato.setComissoes(Collections.singletonList(comissao1));

        // Verifica se os valores recuperados pelos getters correspondem aos valores definidos pelos setters
        assertEquals("CONTRATO-002", newContrato.getNumeroContrato());
        assertEquals("EQ3-CONTRATANTE-ABC", newContrato.getIdEq3Contratante());
        assertEquals("EQ3-CREDOR-XYZ", newContrato.getIdEq3Credor());
        assertEquals(new BigDecimal("60000.00"), newContrato.getValorContratoAbertura());
        assertEquals(new BigDecimal("30000.00"), newContrato.getValorSaldoAtualizadoContrato());
        assertEquals("2024-06-01", newContrato.getDataInicioOperacao());
        assertEquals("2026-06-01", newContrato.getDataLimiteOperacao());
        assertEquals("CDI", newContrato.getNomeIndexador());
        assertEquals(new BigDecimal("0.75"), newContrato.getPercentualTaxaCarta());
        assertEquals("Trimestral", newContrato.getTipoPagamentoComissao());
        assertEquals("Cartao", newContrato.getFormaPagamento());
        assertEquals(90, newContrato.getPeriodicidadeComissao());
        assertNotNull(newContrato.getComissoes());
        assertEquals(1, newContrato.getComissoes().size());
        assertTrue(newContrato.getComissoes().contains(comissao1));
    }

    @Test
    @DisplayName("Deve testar NoArgsConstructor")
    void shouldTestNoArgsConstructor() {
        // Testa o construtor sem argumentos para garantir que ele possa criar uma instância vazia
        Contrato noArgsContrato = new Contrato();
        assertNotNull(noArgsContrato); // Verifica se a instância não é nula
    }

    @Test
    @DisplayName("Deve lidar com lista vazia de Comissões")
    void shouldHandleEmptyListOfComissoes() {
        // Cria um contrato com uma lista vazia de comissões para testar este cenário
        Contrato contratoWithoutComissoes = new Contrato(
                "CONTRATO-003", "ID-CONTRATANTE", "ID-CREDOR",
                new BigDecimal("10000.00"), new BigDecimal("5000.00"),
                "2023-01-01", "2024-01-01", "IGPM",
                new BigDecimal("0.2"), "Anual", "Transferencia", 365,
                Collections.emptyList() // Passa uma lista vazia
        );
        // Verifica se a lista de comissões não é nula (apenas vazia)
        assertNotNull(contratoWithoutComissoes.getComissoes());
        // Verifica se a lista de comissões está realmente vazia
        assertTrue(contratoWithoutComissoes.getComissoes().isEmpty());
    }

    @Test
    @DisplayName("Deve testar métodos equals e hashCode")
    void shouldTestEqualsAndHashCodeMethods() {
        // Cria uma lista de comissões idêntica à usada no setup
        List<Comissao> comissoesSame = Arrays.asList(comissao1, comissao2);
        // Cria um contrato com os mesmos valores do contrato original
        Contrato sameContrato = new Contrato(
                "CONTRATO-001",
                "EQ3-CONTRATANTE-XYZ",
                "EQ3-CREDOR-ABC",
                new BigDecimal("50000.00"),
                new BigDecimal("25000.00"),
                "2023-01-01",
                "2025-12-31",
                "IPCA",
                new BigDecimal("0.5"),
                "Mensal",
                "Boleto",
                30,
                comissoesSame
        );

        // Cria um contrato com um número de contrato diferente, tornando-o diferente
        Contrato differentContrato = new Contrato(
                "CONTRATO-00X", // Alterado para ser diferente
                "EQ3-CONTRATANTE-XYZ",
                "EQ3-CREDOR-ABC",
                new BigDecimal("50000.00"),
                new BigDecimal("25000.00"),
                "2023-01-01",
                "2025-12-31",
                "IPCA",
                new BigDecimal("0.5"),
                "Mensal",
                "Boleto",
                30,
                comissoesSame
        );

        // Verifica se o contrato original é igual ao contrato com os mesmos valores
        assertEquals(contrato, sameContrato);
        // Verifica se o contrato original não é igual ao contrato diferente
        assertNotEquals(contrato, differentContrato);
        // Verifica se os códigos hash são iguais para objetos considerados iguais
        assertEquals(contrato.hashCode(), sameContrato.hashCode());
        // Verifica se os códigos hash são diferentes para objetos considerados diferentes
        assertNotEquals(contrato.hashCode(), differentContrato.hashCode());
    }

    @Test
    @DisplayName("Deve testar o método toString")
    void shouldTestToStringMethod() {
        // Define uma parte esperada da string gerada pelo toString()
        String expectedToStringPart = "Contrato(numeroContrato=CONTRATO-001, idEq3Contratante=EQ3-CONTRATANTE-XYZ";
        // Verifica se a string do toString() contém a parte esperada
        assertTrue(contrato.toString().contains(expectedToStringPart));
        // Verifica se o toString() também inclui parte do toString() da lista aninhada de Comissões
        assertTrue(contrato.toString().contains("comissoes=[Comissao(numeroComissao=1,"));
    }
}