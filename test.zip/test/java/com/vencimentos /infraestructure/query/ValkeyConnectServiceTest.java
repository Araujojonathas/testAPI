package com.vencimentos.infraestruture.query;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

class ValkeyConnectServiceTest {

    @Mock
    private RedisTemplate<String, String> redisTemplate;

    @Mock
    private ListOperations<String, String> listOperations;

    @InjectMocks
    private ValkeyConnectService valkeyConnectService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Quando redisTemplate.opsForList() for chamado, retorne o mock de listOperations
        when(redisTemplate.opsForList()).thenReturn(listOperations);
    }

    @Test
    @DisplayName("Deve retornar uma lista de contratos quando contratos são encontrados para o ID")
    void getContratosByIdEq3_ShouldReturnListOfContracts_WhenContractsExist() {
        // Arrange
        String idContratante = "idContratante123";
        List<String> expectedContracts = Arrays.asList("contrato1", "contrato2", "contrato3");

        // Configura o comportamento do mock:
        // Quando listOperations.range for chamado com os parâmetros corretos, retorne expectedContracts
        when(listOperations.range(idContratante, 0, -1)).thenReturn(expectedContracts);

        // Act
        List<String> actualContracts = valkeyConnectService.getContratosByIdEq3(idContratante);

        // Assert
        assertNotNull(actualContracts);
        assertEquals(expectedContracts.size(), actualContracts.size());
        assertEquals(expectedContracts, actualContracts);

        // Verifica se o método range do listOperations foi chamado exatamente uma vez com os parâmetros corretos
        verify(listOperations, times(1)).range(idContratante, 0, -1);
        // Verifica se opsForList foi chamado uma vez no redisTemplate
        verify(redisTemplate, times(1)).opsForList();
    }

    @Test
    @DisplayName("Deve retornar uma lista vazia quando nenhum contrato é encontrado para o ID")
    void getContratosByIdEq3_ShouldReturnEmptyList_WhenNoContractsExist() {
        // Arrange
        String idContratante = "idContratante456";

        // Configura o comportamento do mock para retornar uma lista vazia
        when(listOperations.range(idContratante, 0, -1)).thenReturn(Collections.emptyList());

        // Act
        List<String> actualContracts = valkeyConnectService.getContratosByIdEq3(idContratante);

        // Assert
        assertNotNull(actualContracts);
        assertTrue(actualContracts.isEmpty());

        // Verifica se o método range do listOperations foi chamado
        verify(listOperations, times(1)).range(idContratante, 0, -1);
        verify(redisTemplate, times(1)).opsForList();
    }

    @Test
    @DisplayName("Deve retornar uma lista vazia quando o ID do contratante é nulo")
    void getContratosByIdEq3_ShouldReturnEmptyList_WhenIdIsNull() {
        // Arrange
        String idContratante = null;

        // Embora a classe `ValkeyConnectService` não tenha validação explícita para ID nulo,
        // o `RedisTemplate` pode se comportar de maneira específica.
        // Para este teste, vamos assumir que `range` com chave nula retornaria uma lista vazia ou lançaria uma exceção.
        // O Mockito nos permite definir esse comportamento.
        when(listOperations.range(eq(idContratante), anyLong(), anyLong())).thenReturn(Collections.emptyList());

        // Act
        List<String> actualContracts = valkeyConnectService.getContratosByIdEq3(idContratante);

        // Assert
        assertNotNull(actualContracts);
        assertTrue(actualContracts.isEmpty());

        // Verifica se o método range do listOperations foi chamado, mesmo com ID nulo
        verify(listOperations, times(1)).range(eq(idContratante), anyLong(), anyLong());
        verify(redisTemplate, times(1)).opsForList();
    }

    @Test
    @DisplayName("Deve retornar uma lista vazia quando o ID do contratante é vazio")
    void getContratosByIdEq3_ShouldReturnEmptyList_WhenIdIsBlank() {
        // Arrange
        String idContratante = "   "; // Espaços em branco

        // Configura o comportamento do mock para retornar uma lista vazia
        when(listOperations.range(idContratante, 0, -1)).thenReturn(Collections.emptyList());

        // Act
        List<String> actualContracts = valkeyConnectService.getContratosByIdEq3(idContratante);

        // Assert
        assertNotNull(actualContracts);
        assertTrue(actualContracts.isEmpty());

        // Verifica se o método range do listOperations foi chamado
        verify(listOperations, times(1)).range(idContratante, 0, -1);
        verify(redisTemplate, times(1)).opsForList();
    }
}