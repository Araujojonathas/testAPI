package com.vencimentos.infraestruture.repository;

import com.vencimentos.infraestruture.query.ValkeyConnectService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

// Estende com MockitoExtension para habilitar o uso de anotações Mockito no JUnit 5.
@ExtendWith(MockitoExtension.class)
class ContratoRepositoryTest {

    // Cria um mock da interface ValkeyConnectService.
    // Isso nos permite simular o comportamento do serviço Valkey sem realmente
    // precisar de uma conexão com o Valkey, isolando o teste do repositório.
    @Mock
    private ValkeyConnectService valkeyConnectService;

    // Injeta os mocks criados (como valkeyConnectService) na instância de ContratoRepository.
    // Mockito tentará injetar via construtor, setter ou campo.
    @InjectMocks
    private ContratoRepository contratoRepository;

    // Variáveis que serão usadas em vários testes para manter a consistência.
    private String idEq3Contratante;
    private List<String> contratosEsperados;

    // Método de configuração que é executado antes de cada método de teste.
    // Garante que cada teste comece com um estado limpo e previsível.
    @BeforeEach
    void setUp() {
        idEq3Contratante = "EQ3-CONTRATANTE-001";
        contratosEsperados = Arrays.asList("CONTRATO-001", "CONTRATO-002", "CONTRATO-003");
    }

    @Test
    @DisplayName("Deve retornar com sucesso uma lista de contratos para um dado idEq3Contratante válido")
    void shouldReturnListOfContractsWhenGivenValidId() {
        // Dado (Arrange): Define o comportamento do mock.
        // Quando o método getContratosByIdEq3 for chamado no mock valkeyConnectService
        // com o idEq3Contratante específico, ele deve retornar a lista de contratosEsperados.
        when(valkeyConnectService.getContratosByIdEq3(idEq3Contratante))
                .thenReturn(contratosEsperados);

        // Quando (Act): Chama o método do repositório que estamos testando.
        List<String> contratosRetornados = contratoRepository.buscarContratosPorId(idEq3Contratante);

        // Então (Assert): Verifica os resultados da execução.
        // Garante que a lista retornada não é nula.
        assertNotNull(contratosRetornados, "A lista de contratos não deve ser nula.");
        // Garante que o tamanho da lista retornada é o esperado.
        assertEquals(3, contratosRetornados.size(), "O número de contratos retornados deve ser 3.");
        // Garante que a lista retornada é exatamente igual à lista esperada.
        assertEquals(contratosEsperados, contratosRetornados, "A lista de contratos deve corresponder à esperada.");

        // Verificação (Verify): Garante que o mock foi interagido conforme o esperado.
        // Verifica que o método getContratosByIdEq3 no valkeyConnectService mockado
        // foi chamado exatamente uma vez com o argumento idEq3Contratante correto.
        verify(valkeyConnectService, times(1)).getContratosByIdEq3(idEq3Contratante);
    }

    @Test
    @DisplayName("Deve retornar uma lista vazia se nenhum contrato for encontrado para o idEq3Contratante fornecido")
    void shouldReturnEmptyListWhenNoContractsFound() {
        // Dado (Arrange): Configura o mock para retornar uma lista vazia.
        List<String> contratosVazios = Collections.emptyList();
        when(valkeyConnectService.getContratosByIdEq3(idEq3Contratante))
                .thenReturn(contratosVazios);

        // Quando (Act): Chama o método do repositório.
        List<String> contratosRetornados = contratoRepository.buscarContratosPorId(idEq3Contratante);

        // Então (Assert): Verifica o resultado.
        assertNotNull(contratosRetornados, "A lista retornada não deve ser nula, mesmo que vazia.");
        assertEquals(0, contratosRetornados.size(), "O número de contratos retornados deve ser 0.");
        assertEquals(contratosVazios, contratosRetornados, "A lista retornada deve ser vazia.");

        // Verificação (Verify): Garante que o método mockado foi chamado uma vez.
        verify(valkeyConnectService, times(1)).getContratosByIdEq3(idEq3Contratante);
    }

    @Test
    @DisplayName("Deve retornar nulo se o ValkeyConnectService retornar nulo (embora uma lista vazia seja geralmente preferida)")
    void shouldReturnNullWhenValkeyConnectServiceReturnsNull() {
        // Dado (Arrange): Configura o mock para retornar nulo.
        // Isso simula um cenário em que o serviço subjacente pode retornar nulo.
        when(valkeyConnectService.getContratosByIdEq3(idEq3Contratante))
                .thenReturn(null);

        // Quando (Act): Chama o método do repositório.
        List<String> contratosRetornados = contratoRepository.buscarContratosPorId(idEq3Contratante);

        // Então (Assert): Verifica que o resultado é nulo.
        assertEquals(null, contratosRetornados, "A lista de contratos deve ser nula se o serviço retornar nulo.");

        // Verificação (Verify): Garante que o método mockado foi chamado uma vez.
        verify(valkeyConnectService, times(1)).getContratosByIdEq3(idEq3Contratante);
    }
}