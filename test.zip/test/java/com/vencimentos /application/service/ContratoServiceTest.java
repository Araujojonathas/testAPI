package com.vencimentos.application.service;

import com.vencimentos.adapters.application.dto.ComissaoResponse;
import com.vencimentos.adapters.application.dto.ContratoResponse;
import com.vencimentos.infraestruture.query.ValkeyConnectService;
import com.vencimentos.infraestruture.repository.ContratoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ContratoServiceTest {

    @Mock
    private ContratoRepository contratoRepository;

    @Mock
    private ValkeyConnectService valkeyConnectService;

    @InjectMocks
    private ContratoService contratoService;

    // Método auxiliar para criar JSON simulando um contrato e uma comissão
    private String createContratoComissaoJson(String numeroContrato, String idEq3Contratante, String idEq3Credor,
                                              String valorContratoAbertura, String valorSaldoAtualizadoContrato,
                                              String dataInicioOperacao, String dataLimiteOperacao, String nomeIndexador,
                                              String percentualTaxaCarta, String tipoPagamentoComissao, int periodicidadeComissao,
                                              int numeroComissao, String tipoComissao, String situacaoComissao,
                                              String indicadorComissaoAtraso, String dataInicioVigenciaComissao,
                                              String dataVencimentoComissao, String valorEsperadoAberturaComissao,
                                              String valorAberturaComissao, String valorPago, String valorPagoJuros,
                                              String valorMultaComissao, String valorMoraComissao, String valorSaldoAtualizadoComissao) {

        return String.format(
                "{" +
                        "\"numero_contrato\": \"%s\"," +
                        "\"id_eq3_contratante\": \"%s\"," +
                        "\"id_eq3_credor\": \"%s\"," +
                        "\"valor_contrato_abertura\": \"%s\"," +
                        "\"valor_saldo_atualizado_contrato\": \"%s\"," +
                        "\"data_inicio_operacao\": \"%s\"," +
                        "\"data_limite_operacao\": \"%s\"," +
                        "\"nome_indexador\": \"%s\"," +
                        "\"percentual_taxa_carta\": \"%s\"," +
                        "\"tipo_pagamento_comissao\": \"%s\"," +
                        "\"periodicidade_comissao\": %d," +
                        "\"numero_comissao\": %d," +
                        "\"tipo_comissao\": \"%s\"," +
                        "\"situacao_comissao\": \"%s\"," +
                        "\"indicador_comissao_atraso\": \"%s\"," +
                        "\"data_inicio_vigencia_comissao\": \"%s\"," +
                        "\"data_vencimento_comissao\": \"%s\"," +
                        "\"valor_esperado_abertura_comissao\": \"%s\"," +
                        "\"valor_abertura_comissao\": \"%s\"," +
                        "\"valor_pago\": \"%s\"," +
                        "\"valor_pago_juros\": \"%s\"," +
                        "\"valor_multa_comissao\": \"%s\"," +
                        "\"valor_mora_comissao\": \"%s\"," +
                        "\"valor_saldo_atualizado_comissao\": \"%s\"" +
                        "}",
                numeroContrato, idEq3Contratante, idEq3Credor,
                valorContratoAbertura, valorSaldoAtualizadoContrato,
                dataInicioOperacao, dataLimiteOperacao, nomeIndexador,
                percentualTaxaCarta, tipoPagamentoComissao, periodicidadeComissao,
                numeroComissao, tipoComissao, situacaoComissao,
                indicadorComissaoAtraso, dataInicioVigenciaComissao,
                dataVencimentoComissao, valorEsperadoAberturaComissao,
                valorAberturaComissao, valorPago, valorPagoJuros,
                valorMultaComissao, valorMoraComissao, valorSaldoAtualizadoComissao
        );
    }

    @Test
    @DisplayName("Deve retornar null quando nenhum contrato for encontrado no Valkey")
    void deveRetornarNuloQuandoNenhumContratoEncontrado() {
        String idEq3 = "123";
        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(null);

        ContratoResponse response = contratoService.buscarContrato(idEq3);

        assertNull(response);
    }

    @Test
    @DisplayName("Deve retornar null quando Valkey retorna lista vazia")
    void deveRetornarNuloQuandoListaVazia() {
        String idEq3 = "456";
        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(Collections.emptyList());

        ContratoResponse response = contratoService.buscarContrato(idEq3);

        assertNull(response);
    }

    @Test
    @DisplayName("Deve mapear corretamente os dados de contrato com comissão pendente")
    void deveMapearContratoComComissaoPendente() {
        String idEq3 = "ID01";
        String json = createContratoComissaoJson(
                "CONTRATO-01", idEq3, "CREDOR-01",
                "1000.00", "900.00", "2023-01-01", "2024-01-01",
                "IPCA", "0.05", "MENSAL", 1, 101, "TIPO_A", "PENDENTE", "N",
                "2023-01-01", "2023-01-31", "100.00", "0.00", "0.00", "0.00", "0.00", "0.00", "0.00"
        );

        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(Collections.singletonList(json));

        ContratoResponse response = contratoService.buscarContrato(idEq3);

        assertNotNull(response);
        assertEquals("CONTRATO-01", response.getNumeroContrato());
        assertEquals(idEq3, response.getIdEq3Contratante());

        ComissaoResponse comissao = response.getComissoes().get(0);
        assertEquals(101, comissao.getNumeroComissao());
        assertEquals("PENDENTE", comissao.getSituacao());
        assertEquals(new BigDecimal("100.00"), comissao.getValorEsperadoAbertura());
    }

    @Test
    @DisplayName("Deve mapear corretamente os dados de comissão recebida")
    void deveMapearContratoComComissaoRecebida() {
        String idEq3 = "ID02";
        String json = createContratoComissaoJson(
                "CONTRATO-02", idEq3, "CREDOR-02",
                "2000.00", "1800.00", "2023-02-01", "2024-02-01",
                "SELIC", "0.03", "ANUAL", 1, 102, "TIPO_B", "RECEBIDA", "N",
                "2023-02-01", "2023-02-28", "0.00", "500.00", "480.00", "10.00", "5.00", "2.00", "1.00"
        );

        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(Collections.singletonList(json));

        ContratoResponse response = contratoService.buscarContrato(idEq3);

        assertNotNull(response);
        ComissaoResponse comissao = response.getComissoes().get(0);
        assertEquals("RECEBIDA", comissao.getSituacao());
        assertEquals(new BigDecimal("500.00"), comissao.getValorAbertura());
        assertEquals(new BigDecimal("480.00"), comissao.getValorPago());
    }

    @Test
    @DisplayName("Deve mapear corretamente múltiplas comissões do mesmo contrato")
    void deveMapearMultiplasComissoesDoContrato() {
        String idEq3 = "ID03";

        String json1 = createContratoComissaoJson(
                "CONTRATO-03", idEq3, "CREDOR-03",
                "3000.00", "2700.00", "2023-03-01", "2024-03-01",
                "CDI", "0.04", "TRIMESTRAL", 1, 201, "TIPO_C", "PENDENTE", "N",
                "2023-03-01", "2023-03-31", "300.00", "0.00", "0.00", "0.00", "0.00", "0.00", "0.00"
        );
        String json2 = createContratoComissaoJson(
                "CONTRATO-03", idEq3, "CREDOR-03",
                "3000.00", "2700.00", "2023-03-01", "2024-03-01",
                "CDI", "0.04", "TRIMESTRAL", 1, 202, "TIPO_D", "RECEBIDA", "S",
                "2023-04-01", "2023-04-30", "0.00", "600.00", "580.00", "10.00", "5.00", "2.00", "1.00"
        );

        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(Arrays.asList(json1, json2));

        ContratoResponse response = contratoService.buscarContrato(idEq3);

        assertNotNull(response);
        assertEquals(2, response.getComissoes().size());
    }

    @Test
    @DisplayName("Deve ignorar JSON malformado e processar os válidos")
    void deveIgnorarJsonInvalido() {
        String idEq3 = "ID04";
        String valido = createContratoComissaoJson(
                "CONTRATO-04", idEq3, "CREDOR-04",
                "4000.00", "3800.00", "2023-05-01", "2024-05-01",
                "IGPM", "0.06", "MENSAL", 1, 301, "TIPO_E", "ATIVO", "N",
                "2023-05-01", "2023-05-31", "0.00", "700.00", "680.00", "15.00", "7.00", "4.00", "3.00"
        );

        String malformado = "{ \"campo_invalido\": "; // JSON mal formatado

        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(Arrays.asList(malformado, valido));

        ContratoResponse response = contratoService.buscarContrato(idEq3);

        assertNotNull(response);
        assertEquals(1, response.getComissoes().size());
        assertEquals(301, response.getComissoes().get(0).getNumeroComissao());
    }
}
