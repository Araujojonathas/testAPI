package com.exemplo.redis;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import redis.clients.jedis.Jedis;

import java.io.File;
import java.nio.file.Files;
import java.util.Objects;

public class RedisSeeder {
    public static void main(String[] args) throws Exception {
        // Conexão com Redis local na porta 6379
        Jedis jedis = new Jedis("localhost", 6379);

        // Autenticação com senha
        jedis.auth("12345678"); // 🔒 Substitua pela senha real usada no Redis

        ObjectMapper mapper = new ObjectMapper();
        File dir = new File("src/main/resources/json");

        for (File file : Objects.requireNonNull(dir.listFiles((d, name) -> name.endsWith(".json")))) {
            String content = Files.readString(file.toPath());
            JsonNode root = mapper.readTree(content);

            if (root.isArray()) {
                for (JsonNode node : root) {
                    JsonNode keyNode = node.get("id_eq3_contratante");
                    if (keyNode != null) {
                        String key = keyNode.asText();
                        jedis.rpush(key, mapper.writeValueAsString(node));
                        System.out.println("✔ Inserido no Redis: " + key);
                    } else {
                        System.err.println("⚠ Campo 'id_eq3_contratante' não encontrado em: " + file.getName());
                    }
                }
            } else {
                System.err.println("⚠ JSON não é um array: " + file.getName());
            }
        }

        jedis.close();
    }
}
