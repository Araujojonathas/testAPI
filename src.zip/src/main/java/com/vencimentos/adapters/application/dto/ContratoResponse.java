package com.vencimentos.adapters.application.dto;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContratoResponse {
    private String numeroContrato;
    private String idEq3Contratante;
    private String idEq3Credor;
    private BigDecimal valorContratoAbertura;
    private BigDecimal valorSaldoAtualizadoContrato;
    private String dataInicioOperacao;
    private String dataLimiteOperacao;
    private String nomeIndexador;
    private BigDecimal percentualTaxaCarta;
    private String tipoPagamentoComissao;
    private int periodicidadeComissao;
    private List<ComissaoResponse> comissoes;
}
