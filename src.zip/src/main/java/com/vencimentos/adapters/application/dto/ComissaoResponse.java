package com.vencimentos.adapters.application.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;


@Data
@AllArgsConstructor
public class ComissaoResponse {
    private int numeroComissao;
    private String tipoComissao;
    private String situacaoComissao;
    private BigDecimal valorComissaoAbertura;
    private BigDecimal valorSaldoAtualizadoComissao;
    private String dataInicioVigenciaComissao;
    private String dataVencimentoComissao;
}
