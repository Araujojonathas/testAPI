package com.vencimentos.infraestruture.query;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ValkeyConnectService {
    private final RedisTemplate<String, String> redisTemplate;

    public ValkeyConnectService(RedisTemplate<String, String> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public List<String> getContratosByIdEq3(String idEq3Contratante) {
        return redisTemplate.opsForList().range(idEq3Contratante, 0, -1);
    }
}
