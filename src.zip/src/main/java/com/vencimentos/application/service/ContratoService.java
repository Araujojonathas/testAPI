package com.vencimentos.application.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vencimentos.adapters.application.dto.ComissaoResponse;
import com.vencimentos.adapters.application.dto.ContratoResponse;
import com.vencimentos.infraestruture.query.ValkeyConnectService;
import com.vencimentos.infraestruture.repository.ContratoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class ContratoService {

    private final ContratoRepository contratoRepository;
    private final ValkeyConnectService valkeyConnectService;

    public ContratoService(ContratoRepository contratoRepository,
                           ValkeyConnectService valkeyConnectService) {
        this.contratoRepository = contratoRepository;
        this.valkeyConnectService = valkeyConnectService;
    }

    public ContratoResponse buscarContrato(String idEq3Contratante) {
        List<String> contratosJson = valkeyConnectService.getContratosByIdEq3(idEq3Contratante);

        if (contratosJson == null || contratosJson.isEmpty()) {
            return null;
        }

        ObjectMapper objectMapper = new ObjectMapper();
        List<ComissaoResponse> comissoes = new ArrayList<>();
        ContratoResponse contratoResponse = null;

        for (String json : contratosJson) {
            try {
                JsonNode root = objectMapper.readTree(json);

                ComissaoResponse comissao = new ComissaoResponse(
                        root.path("numero_comissao").asInt(),
                        root.path("tipo_comissao").asText(),
                        root.path("situacao_comissao").asText(),
                        new BigDecimal(root.path("valor_comissao_abertura").asDouble()),
                        new BigDecimal(root.path("valor_saldo_atualizado_comissao").asDouble()),
                        root.path("data_inicio_vigencia_comissao").asText(),
                        root.path("data_vencimento_comissao").asText()
                );
                comissoes.add(comissao);

                if (contratoResponse == null) {
                    contratoResponse = new ContratoResponse(
                            root.path("numero_contrato").asText(),
                            root.path("id_eq3_contratante").asText(),
                            root.path("id_eq3_credor").asText(),
                            new BigDecimal(root.path("valor_contrato_abertura").asDouble()),
                            new BigDecimal(root.path("valor_saldo_atualizado_contrato").asDouble()),
                            root.path("data_inicio_operacao").asText(),
                            root.path("data_limite_operacao").asText(),
                            root.path("nome_indexador").asText(),
                            new BigDecimal(root.path("percentual_taxa_carta").asDouble()),
                            root.path("tipo_pagamento_comissao").asText(),
                            root.path("periodicidade_comissao").asInt(),
                            null // comissoes será setado depois
                    );
                }

            } catch (Exception e) {
                e.printStackTrace(); // ou log com SLF4J
            }
        }

        if (contratoResponse != null) {
            contratoResponse.setComissoes(comissoes);
        }

        return contratoResponse;
    }
}
