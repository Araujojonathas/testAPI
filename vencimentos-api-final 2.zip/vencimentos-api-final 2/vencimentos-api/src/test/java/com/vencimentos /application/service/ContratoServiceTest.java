package com.vencimentos.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vencimentos.domain.model.Comissao;
import com.vencimentos.domain.model.Contrato;
import com.vencimentos.infraestruture.query.ValkeyConnectService;
import com.vencimentos.infraestruture.repository.ContratoRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ContratoServiceTest {

    @Mock
    private ContratoRepository contratoRepository;

    @Mock
    private ValkeyConnectService valkeyConnectService;  // Mock para injetar no serviço

    @InjectMocks
    private ContratoService contratoService;

    @Test
    public void testBuscarContrato_retornaContratoResponse() throws Exception {
        String idEq3 = "49e7672d-9bf4-445b-8ee0-0fc736b3dac";

        String jsonSingleContrato = """
        {
          "numero_contrato": "422120192000",
          "id_eq3_contratante": "abc-123-uuid",
          "id_eq3_credor": "credor-xyz",
          "valor_contrato_abertura": 10000.00,
          "valor_saldo_atualizado_contrato": 9500.00,
          "data_inicio_operacao": "2025-09-10",
          "data_limite_operacao": "2025-09-10",
          "nome_indexador": "IPCA",
          "percentual_taxa_carta": 1.5,
          "tipo_pagamento_comissao": "Mensal",
          "forma_pagamento": "PIX",
          "periodicidade_comissao": 30,
          "numero_comissao": 1,
          "tipo_comissao": "A",
          "situacao_comissao": "ATIVA",
          "indicador_comissao_atraso": "N",
          "data_inicio_vigencia_comissao": "2025-09-01",
          "data_vencimento_comissao": "2025-10-01",
          "valor_esperado_comissao_abertura": 120.00,
          "valor_comissao_abertura": 100.00,
          "valor_saldo_atualizado_comissao": 80.00,
          "valor_pago": 20.00,
          "valor_pago_juros": 0.00,
          "valor_multa_comissao": 0.00,
          "valor_mora_comissao": 0.00,
          "valor_juros_comissao": 0.00
        }
        """;

        // Mock do ValkeyConnectService para retornar JSON em lista de strings
        when(valkeyConnectService.getContratosByIdEq3(idEq3)).thenReturn(List.of(jsonSingleContrato));


        // Chamada ao método de serviço que usa o valkeyConnectService
        var response = contratoService.buscarContrato(idEq3);

        assertNotNull(response);
        assertEquals("422120192000", response.getNumeroContrato());
        assertNotNull(response.getComissoes());
        assertEquals(1, response.getComissoes().size());
        assertEquals("N", response.getComissoes().get(0).getIndicadorAtraso());
    }
}
