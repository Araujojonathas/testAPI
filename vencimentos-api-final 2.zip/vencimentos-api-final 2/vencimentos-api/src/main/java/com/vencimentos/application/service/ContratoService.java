package com.vencimentos.application.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vencimentos.adapters.application.dto.ComissaoResponse;
import com.vencimentos.adapters.application.dto.ContratoResponse;
import com.vencimentos.infraestruture.query.ValkeyConnectService;
import com.vencimentos.infraestruture.repository.ContratoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class ContratoService {

    private final ContratoRepository contratoRepository;
    private final ValkeyConnectService valkeyConnectService;

    public ContratoService(ContratoRepository contratoRepository,
                           ValkeyConnectService valkeyConnectService) {
        this.contratoRepository = contratoRepository;
        this.valkeyConnectService = valkeyConnectService;
    }

    public ContratoResponse buscarContrato(String idEq3Contratante) {
        List<String> contratosJson = valkeyConnectService.getContratosByIdEq3(idEq3Contratante);

        if (contratosJson == null || contratosJson.isEmpty()) {
            return null;
        }

        ObjectMapper objectMapper = new ObjectMapper();
        List<ComissaoResponse> comissoes = new ArrayList<>();
        ContratoResponse contratoResponse = null;

        for (String json : contratosJson) {
            try {
                JsonNode root = objectMapper.readTree(json);

                String situacao = root.path("situacao_comissao").asText();

                BigDecimal valorEsperado = null;
                BigDecimal valorAbertura = null;
                BigDecimal valorPago = null;
                BigDecimal valorPagoJuros = null;
                BigDecimal valorMulta = null;
                BigDecimal valorMora = null;
                BigDecimal valorSaldoAtualizado = null;
                BigDecimal valorJuros = null;


                if ("PENDENTE".equalsIgnoreCase(situacao)) {
                    valorEsperado = new BigDecimal(root.path("valor_esperado_abertura_comissao").asText("0"));
                } else {
                    valorAbertura = new BigDecimal(root.path("valor_abertura_comissao").asText("0"));
                    valorPago = new BigDecimal(root.path("valor_pago").asText("0"));
                    valorPagoJuros = new BigDecimal(root.path("valor_pago_juros").asText("0"));
                    valorMulta = new BigDecimal(root.path("valor_multa_comissao").asText("0"));
                    valorMora = new BigDecimal(root.path("valor_mora_comissao").asText("0"));
                    valorSaldoAtualizado = new BigDecimal(root.path("valor_saldo_atualizado_comissao").asText("0"));
                    valorJuros = new BigDecimal(root.path("valor_saldo_atualizado_comissao").asText("0"));


                }

                ComissaoResponse comissao = ComissaoResponse.builder()
                        .numeroComissao(root.path("numero_comissao").asInt())
                        .tipo(root.path("tipo_comissao").asText())
                        .situacao(situacao)
                        .indicadorAtraso(root.path("indicador_comissao_atraso").asText())
                        .dataInicioVigencia(root.path("data_inicio_vigencia_comissao").asText())
                        .dataVencimento(root.path("data_vencimento_comissao").asText())
                        .valorEsperadoAbertura(valorEsperado)
                        .valorAbertura(valorAbertura)
                        .valorSaldoAtualizado(valorSaldoAtualizado)
                        .valorPago(valorPago)
                        .valorPagoJuros(valorPagoJuros)
                        .valorMulta(valorMulta)
                        .valorMora(valorMora)
                        .valorJuros(valorJuros)
                        .build();

                comissoes.add(comissao);
                if (contratoResponse == null) {
                    contratoResponse = ContratoResponse.builder()
                            .numeroContrato(root.path("numero_contrato").asText())
                            .idEq3Contratante(root.path("id_eq3_contratante").asText())
                            .idEq3Credor(root.path("id_eq3_credor").asText())
                            .valorAbertura(new BigDecimal(root.path("valor_contrato_abertura").asText("0.00")))
                            .valorSaldoAtualizado(new BigDecimal(root.path("valor_saldo_atualizado_contrato").asText("0.00")))
                            .dataInicioOperacao(root.path("data_inicio_operacao").asText())
                            .dataLimiteOperacao(root.path("data_limite_operacao").asText())
                            .nomeIndexador(root.path("nome_indexador").asText())
                            .percentualTaxaCarta(new BigDecimal(root.path("percentual_taxa_carta").asText("0.000000")))
                            .tipoPagamentoComissao(root.path("tipo_pagamento_comissao").asText())
                            .periodicidadeComissao(root.path("periodicidade_comissao").asInt())
                            .comissoes(new ArrayList<>()) // será setado depois
                            .build();
                }

            } catch (Exception e) {
                // Substitua por logger real em produção
                System.err.println("Erro ao processar JSON do Redis: " + e.getMessage());
            }
        }

        if (contratoResponse != null) {
            contratoResponse.setComissoes(comissoes);
        }

        return contratoResponse;
    }
}
