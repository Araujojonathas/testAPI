package com.vencimentos.infraestruture.repository;

import com.vencimentos.infraestruture.query.ValkeyConnectService;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ContratoRepository {

    private final ValkeyConnectService valkeyConnectService;

    public ContratoRepository(ValkeyConnectService valkeyConnectService) {
        this.valkeyConnectService = valkeyConnectService;
    }

    public List<String> buscarContratosPorId(String idEq3Contratante) {
        return valkeyConnectService.getContratosByIdEq3(idEq3Contratante);
    }
}
