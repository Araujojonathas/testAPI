package com.vencimentos.adapters.application.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;


@Data
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ComissaoResponse {
    private Integer numeroComissao;
    private String tipo;
    private String situacao;
    private String indicadorAtraso;
    private String dataInicioVigencia;
    private String dataVencimento;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorEsperadoAbertura;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorAbertura;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorSaldoAtualizado;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorPago;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorPagoJuros;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorMulta;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorMora;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private BigDecimal valorJuros;
}


