package com.vencimentos.domain.model;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonProperty;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comissao {

    @JsonProperty("numero_comissao")
    private Integer numeroComissao;

    @JsonProperty("tipo_comissao")
    private String tipo;

    @JsonProperty("situacao_comissao")
    private String situacao;

    @JsonProperty("indicador_comissao_atraso")
    private String indicadorAtraso;

    @JsonProperty("data_inicio_vigencia_comissao")
    private String dataInicioVigencia;

    @JsonProperty("data_vencimento_comissao")
    private String dataVencimento;

    @JsonProperty("valor_esperado_comissao_abertura")
    private BigDecimal valorEsperadoAbertura;

    @JsonProperty("valor_comissao_abertura")
    private BigDecimal valorAbertura;

    @JsonProperty("valor_saldo_atualizado_comissao")
    private BigDecimal valorSaldoAtualizado;

    @JsonProperty("valor_pago")
    private BigDecimal valorPago;

    @JsonProperty("valor_pago_juros")
    private BigDecimal valorPagoJuros;

    @JsonProperty("valor_multa_comissao")
    private BigDecimal valorMulta;

    @JsonProperty("valor_mora_comissao")
    private BigDecimal valorMora;

    @JsonProperty("valor_juros_comissao")
    private BigDecimal valorJuros;

}