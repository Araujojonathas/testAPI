package com.vencimentos.adapters.controller;

import com.vencimentos.adapters.application.dto.ContratoResponse;
import com.vencimentos.application.service.ContratoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1")
public class VencimentosController {

    private final ContratoService contratoService;

    public VencimentosController(ContratoService contratoService) {
        this.contratoService = contratoService;
    }

    // Método para chamadas sem o idEq3Contratante
    @GetMapping("/")
    public ResponseEntity<?> getContratoSemId() {
        return ResponseEntity.badRequest()
                .body("O parâmetro 'idEq3Contratante' é obrigatório na URL.");
    }

    @GetMapping("/contratantes/{idEq3Contratante}/vencimentos")
    public ResponseEntity<?> getContrato(@PathVariable String idEq3Contratante) {
        try {
            if (idEq3Contratante == null || idEq3Contratante.isBlank()) {
                return ResponseEntity.badRequest()
                        .body("O parâmetro 'idEq3Contratante' não pode ser vazio.");
            }

            ContratoResponse contrato = contratoService.buscarContrato(idEq3Contratante);

            if (contrato == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Contratos não encontrados para o id Contratante: " + idEq3Contratante);
            }

            return ResponseEntity.ok(contrato);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Erro interno no servidor ao buscar o contrato: " + e.getMessage());
        }
    }
}
