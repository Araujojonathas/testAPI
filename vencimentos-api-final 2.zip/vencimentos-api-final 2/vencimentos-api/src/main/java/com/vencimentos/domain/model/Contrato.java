package com.vencimentos.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class Contrato {

    @JsonProperty("numero_contrato")
    private String numeroContrato;


    @JsonProperty("id_eq3_contratante")
    private String idEq3Contratante;

    @JsonProperty("id_eq3_credor")
    private String idEq3Credor;

    @JsonProperty("valor_contrato_abertura")
    private BigDecimal valorContratoAbertura;

    @JsonProperty("valor_saldo_atualizado_contrato")
    private BigDecimal valorSaldoAtualizadoContrato;

    @JsonProperty("data_inicio_operacao")
    private String dataInicioOperacao;

    @JsonProperty("data_limite_operacao")
    private String dataLimiteOperacao;

    @JsonProperty("nome_indexador")
    private String nomeIndexador;

    @JsonProperty("percentual_taxa_carta")
    private BigDecimal percentualTaxaCarta;

    @JsonProperty("tipo_pagamento_comissao")
    private String tipoPagamentoComissao;


    @JsonProperty("forma_pagamento")
    private String formaPagamento;

    @JsonProperty("periodicidade_comissao")
    private Integer periodicidadeComissao;

    private List<Comissao> comissoes;

}
